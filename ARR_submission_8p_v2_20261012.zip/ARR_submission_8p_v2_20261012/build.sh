#!/bin/sh
# Build LSR_Synth_ARR.pdf. lineno (review line numbers) needs 4 pdflatex passes.
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
bibtex LSR_Synth_ARR
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
if grep -q -e "Line number reference failed" -e "may have changed" LSR_Synth_ARR.log; then
  echo "Layout not yet stable, running pdflatex once more..."
  pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
fi
echo "Done: LSR_Synth_ARR.pdf"
