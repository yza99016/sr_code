# LSR_Synth_ARR — 8-page version v2 for ACL ARR (2026-10-12)

Main text (Sections 1–6) ends on page 8; Limitations (last ~10 lines spill
onto page 9), References and Appendices A–E follow and do not count toward
the ARR long-paper limit.

Change in v2 (relative to ARR_submission_8p_20261012)
- Removed the unnumbered "AI use statement" section that followed Limitations.
  Per the ARR CFP (https://aclrollingreview.org/cfp, "AI Writing/Coding
  Assistance Policy"), AI use is disclosed in the Responsible NLP Checklist
  (and, for the camera-ready, in Acknowledgements); purely linguistic
  polishing "does not need to be disclosed". The section was not covered by
  the page-limit exemption (only Limitations and Ethical considerations are),
  so it put content on page 9. The removed text is kept in
  AI_USE_STATEMENT_removed.txt for the checklist / camera-ready.

What moved / changed relative to ARR_submission_20261012 (17-page full version):

Moved to the appendix (content unchanged, now referenced from the main text)
- Table 1  method map                        -> Appendix E.1
- Algorithm 1  paired search pseudocode      -> Appendix A.3
- Figure 1  candidate-source bar chart       -> Appendix D.2 (Table 2 carries the same numbers)
- Table 6  knockout effects by operator family -> Appendix D.2
- Discussion paragraph "Positioning of external datasets" -> Appendix E.3

Trimmed in the main text (only text that was stated verbatim elsewhere)
- Sec. 3.1 "Metric scope" paragraph: merged into Sec. 5 "Metric relations"
  (its one new sentence was kept there).
- Sec. 3.2: SR-Scientist human-adjudication comparison -> pointer to Appendix B.2,
  which already contained the same paragraph.
- Sec. 3.2: Eq. (1)+(2) merged into one cases equation; A(M,c) and SA written inline.
- Sec. 4.2: pairing-protocol and metric-definition sentences that repeat Sec. 3
  and the table captions.
- Sec. 5 "Implications for benchmark design": shortened to the three concrete
  recommendations; the full version remains in Appendix E.2.
- Table 5 (knockout): single-column; 95% CIs stated in the caption and text.

Nothing was deleted from the paper: every table, figure, equation and
paragraph still exists either in the main text or in the appendix.

Compile: sh build.sh  /  build.bat  /  latexmk -pdf LSR_Synth_ARR.tex
(review line numbers need four pdflatex passes; the scripts do this).
Camera-ready: change \usepackage[review]{acl} to \usepackage[final]{acl}.
