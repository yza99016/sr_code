@echo off
rem Build LSR_Synth_ARR.pdf. lineno (review line numbers) needs 4 pdflatex passes.
cd /d "%~dp0"
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
bibtex LSR_Synth_ARR
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
findstr /C:"Line number reference failed" /C:"may have changed" LSR_Synth_ARR.log >nul && (
  echo Layout not yet stable, running pdflatex once more...
  pdflatex -interaction=nonstopmode LSR_Synth_ARR.tex
)
echo Done: LSR_Synth_ARR.pdf
